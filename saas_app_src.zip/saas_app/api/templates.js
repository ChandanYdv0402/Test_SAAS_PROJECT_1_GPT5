// Serverless API route for returning website builder templates.
//
// Vercel will automatically treat files in the `api` directory as serverless
// functions. This handler sends a static array of template definitions to
// the client. When deploying on Vercel, this function replaces the
// Express route used for local development.

export default function handler(req, res) {
  const templates = [
    {
      id: 'template1',
      name: 'Business Landing Page',
      html: `<section style="padding: 40px; text-align: center;">
                <h1>Welcome to Your Business</h1>
                <p>Describe your amazing business here.</p>
                <button style="padding: 10px 20px; font-size: 16px;">Learn More</button>
             </section>`
    },
    {
      id: 'template2',
      name: 'Portfolio Gallery',
      html: `<div style="display: flex; flex-wrap: wrap; gap: 20px; padding: 20px;">
                <div style="flex: 1 1 200px; background: #f0f0f0; padding: 20px;">Project 1</div>
                <div style="flex: 1 1 200px; background: #f0f0f0; padding: 20px;">Project 2</div>
                <div style="flex: 1 1 200px; background: #f0f0f0; padding: 20px;">Project 3</div>
             </div>`
    },
    {
      id: 'template3',
      name: 'E-commerce Product',
      html: `<section style="padding: 40px;">
                <h2>Featured Product</h2>
                <img src="https://images.pexels.com/photos/5717089/pexels-photo-5717089.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" alt="Product" style="max-width: 100%; height: auto;">
                <p style="margin-top: 20px;">This is a description of the product. It's the best product ever!</p>
                <button style="padding: 10px 20px; font-size: 16px;">Buy Now</button>
             </section>`
    }
  ];
  res.status(200).json(templates);
}