// Serverless API route for creating a Stripe payment intent.
//
// When deployed on Vercel, this function will be invoked for POST requests
// to /api/payment-intent. It uses the Stripe secret key provided via
// environment variables to create a payment intent and returns the
// client secret to the client. In local development, the Express
// server defined in server.js handles this route instead.

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_4eC39HqLyjWDarjtT1zdp7dc');

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }
  try {
    const { amount, currency } = req.body || {};
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount || 5000,
      currency: currency || 'usd',
      automatic_payment_methods: { enabled: true },
    });
    res.status(200).json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    console.error('Stripe error:', error);
    res.status(500).json({ error: 'Unable to create payment intent' });
  }
}