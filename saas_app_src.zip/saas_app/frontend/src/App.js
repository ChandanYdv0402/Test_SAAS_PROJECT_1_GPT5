import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './components/Home';
import WebsiteBuilder from './components/WebsiteBuilder';
import Payment from './components/Payment';
import MLDemo from './components/MLDemo';

import './App.css';

/**
 * The main entry point for our SaaS application front‑end.
 *
 * We use react‑router to handle navigation between pages. The navigation bar
 * at the top provides links to each major feature: the website builder,
 * payment processing demo, and a machine learning demo. A simple home page
 * introduces the app.
 */
function App() {
  return (
    <Router>
      <div className="App">
        <NavBar />
        <div className="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/builder" element={<WebsiteBuilder />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/ml-demo" element={<MLDemo />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;