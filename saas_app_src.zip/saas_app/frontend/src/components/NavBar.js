import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './NavBar.css';

/**
 * Navigation bar for the SaaS application.
 *
 * Contains links to all major sections of the site. The active link is
 * highlighted based on the current pathname. Styling is defined in
 * NavBar.css.
 */
const NavBar = () => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/builder', label: 'Website Builder' },
    { path: '/payment', label: 'Payment Demo' },
    { path: '/ml-demo', label: 'ML Demo' }
  ];

  return (
    <nav className="navbar">
      <div className="navbar-logo">SaaS App</div>
      <ul className="navbar-menu">
        {navItems.map(item => (
          <li key={item.path} className={location.pathname === item.path ? 'active' : ''}>
            <Link to={item.path}>{item.label}</Link>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default NavBar;