// Machine learning demo using ml5.js. This component loads a pre‑trained
// MobileNet model in the browser, allows users to upload an image,
// and displays the top three classification results.
import React, { useEffect, useRef, useState } from 'react';
import './MLDemo.css';

/**
 * Machine Learning Demo component.
 *
 * This page demonstrates using a pre‑trained image classification model
 * (MobileNet) from the ml5.js library. Users can upload an image, which
 * the model will classify into one of many categories. The top three
 * predictions are displayed along with their probabilities.
 */
const MLDemo = () => {
  const [classifier, setClassifier] = useState(null);
  const [predictions, setPredictions] = useState([]);
  const [loadingModel, setLoadingModel] = useState(true);
  const [loadingPrediction, setLoadingPrediction] = useState(false);
  const [error, setError] = useState('');
  const imgRef = useRef();

  // Load the ml5.js script and initialize the classifier
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/ml5/0.12.2/ml5.min.js';
    script.onload = () => {
      window.ml5.imageClassifier('MobileNet', () => {
        setClassifier(window.ml5.imageClassifier('MobileNet'));
        setLoadingModel(false);
      });
    };
    script.onerror = () => setError('Failed to load ml5 library');
    document.body.appendChild(script);
    return () => document.body.removeChild(script);
  }, []);

  const handleImageChange = async (e) => {
    if (!classifier) return;
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (imgRef.current) {
        imgRef.current.src = reader.result;
        classifyImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const classifyImage = async (imageSrc) => {
    try {
      setLoadingPrediction(true);
      setPredictions([]);
      setError('');
      classifier.classify(imgRef.current, 3, (err, results) => {
        setLoadingPrediction(false);
        if (err) {
          console.error(err);
          setError('Classification failed.');
        } else {
          setPredictions(results);
        }
      });
    } catch (err) {
      console.error(err);
      setError('Classification error.');
      setLoadingPrediction(false);
    }
  };

  return (
    <div className="page ml-demo">
      <h2>Machine Learning Demo</h2>
      <p>
        Upload an image to see how a pre‑trained MobileNet model classifies it.
        The results below show the top three predictions and their confidence
        scores.
      </p>
      {loadingModel ? (
        <p>Loading ML model…</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="ml-content">
          <input type="file" accept="image/*" onChange={handleImageChange} />
          <div className="ml-preview">
            <img ref={imgRef} alt="preview" />
          </div>
          {loadingPrediction && <p>Classifying…</p>}
          {predictions.length > 0 && (
            <div className="ml-results">
              <h4>Predictions:</h4>
              <ul>
                {predictions.map((pred, idx) => (
                  <li key={idx}>{pred.label}: {(pred.confidence * 100).toFixed(2)}%</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MLDemo;