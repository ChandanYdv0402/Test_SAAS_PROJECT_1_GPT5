// Payment integration with Stripe: This component demonstrates how to
// collect card details using Stripe Elements, create a payment intent
// via our backend, and confirm the payment on the client side. The
// credit card information is securely handled by Stripe and never
// touches our servers.
import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';

import './Payment.css';

// Load the Stripe publishable key from environment. During development, this
// is set in .env via the REACT_APP_STRIPE_PUBLISHABLE_KEY variable. For
// production deployment, ensure the environment variable is configured in
// Vercel or your hosting provider.
const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY || 'pk_test_TYooMQauvdEDq54NiTphI7jx');

/**
 * CheckoutForm encapsulates the card element and handles payment submission.
 */
const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const [message, setMessage] = useState('');
  const [processing, setProcessing] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setProcessing(true);
    setMessage('');

    if (!stripe || !elements) {
      return;
    }
    try {
      // Create a payment intent on the server
      const res = await fetch('/api/payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: 5000, currency: 'usd' })
      });
      const { clientSecret, error } = await res.json();
      if (error) throw new Error(error);

      // Confirm the payment on the client
      const paymentResult = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
        },
      });

      if (paymentResult.error) {
        setMessage(`Payment failed: ${paymentResult.error.message}`);
      } else if (paymentResult.paymentIntent && paymentResult.paymentIntent.status === 'succeeded') {
        setMessage('Payment succeeded! Thank you for your purchase.');
      }
    } catch (err) {
      console.error(err);
      setMessage('Payment failed.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="checkout-form">
      <CardElement options={{ hidePostalCode: true }} />
      <button type="submit" disabled={!stripe || processing}>
        {processing ? 'Processing…' : 'Pay $50.00'}
      </button>
      {message && <div className="payment-message">{message}</div>}
      <div className="test-card-info">
        <p><strong>Test card:</strong> 4242 4242 4242 4242 · 04/24 · CVC: 242 · ZIP: 42424</p>
      </div>
    </form>
  );
};

/**
 * Payment component provides the Stripe Elements context and renders the
 * CheckoutForm. It demonstrates a simple payment flow using Stripe’s test
 * environment.
 */
const Payment = () => {
  return (
    <div className="page">
      <h2>Payment Demo</h2>
      <p>Enter the test card details below to simulate a payment.</p>
      <Elements stripe={stripePromise}>
        <CheckoutForm />
      </Elements>
    </div>
  );
};

export default Payment;