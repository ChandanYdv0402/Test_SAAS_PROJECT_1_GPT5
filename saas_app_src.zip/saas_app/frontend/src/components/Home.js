import React from 'react';

/**
 * Home page component.
 *
 * Introduces the SaaS application and briefly describes the available
 * features. Encourages users to explore the website builder, payment demo,
 * and machine learning demo pages.
 */
const Home = () => {
  return (
    <div className="page">
      <h1>Welcome to Our All‑in‑One SaaS Platform</h1>
      <p>
        Build stunning websites, accept payments securely, and explore
        machine learning – all from one cohesive platform. Use the
        navigation above to try out each feature!
      </p>
      <div className="cards-container">
        <div className="card">
          <h3>Website Builder</h3>
          <p>
            Craft custom pages with a drag‑and‑drop editor and choose from
            beautiful templates.
          </p>
        </div>
        <div className="card">
          <h3>Payment Demo</h3>
          <p>
            Experience a seamless checkout flow powered by Stripe’s test
            environment.
          </p>
        </div>
        <div className="card">
          <h3>Machine Learning</h3>
          <p>
            Upload an image and see how a pre‑trained neural network
            categorizes it using ml5.js.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;