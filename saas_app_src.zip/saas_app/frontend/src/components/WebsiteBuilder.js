import React, { useEffect, useRef, useState } from 'react';
import grapesjs from 'grapesjs';
import 'grapesjs/dist/css/grapes.min.css';
import './WebsiteBuilder.css';

/**
 * WebsiteBuilder component initializes GrapesJS when mounted and
 * provides a panel of example templates that users can insert into the
 * editor. It fetches template HTML from the backend via the `/api/templates`
 * endpoint. When a template is selected, it replaces the current content.
 */
const WebsiteBuilder = () => {
  const editorRef = useRef(null);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch available templates from the backend
    fetch('/api/templates')
      .then(res => res.json())
      .then(data => {
        setTemplates(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setError('Failed to load templates');
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    // Initialize GrapesJS editor
    if (!editorRef.current) {
      editorRef.current = grapesjs.init({
        container: '#gjs',
        height: '90vh',
        fromElement: false,
        storageManager: false,
        plugins: [],
        panels: { defaults: [] },
        blockManager: {
          appendTo: '#blocks'
        }
      });
    }
  }, []);

  const loadTemplate = (html) => {
    if (editorRef.current) {
      const editor = editorRef.current;
      editor.DomComponents.clear();
      editor.setComponents(html);
    }
  };

  return (
    <div className="page">
      <h2>Website Builder</h2>
      <p>Select a template to start editing or build your own layout using the editor below.</p>
      {loading ? (
        <p>Loading templates...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <div className="template-buttons">
          {templates.map(tpl => (
            <button key={tpl.id} onClick={() => loadTemplate(tpl.html)}>
              {tpl.name}
            </button>
          ))}
        </div>
      )}
      <div id="gjs" />
    </div>
  );
};

export default WebsiteBuilder;